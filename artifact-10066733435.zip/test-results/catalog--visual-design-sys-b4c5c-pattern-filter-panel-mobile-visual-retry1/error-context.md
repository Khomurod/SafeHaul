# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: visual/catalog.spec.cjs >> @visual design-system catalog >> pattern-filter-panel @ mobile
- Location: e2e/visual/catalog.spec.cjs:273:13

# Error details

```
Error: expect(page).toHaveScreenshot(expected) failed

  132 pixels (ratio 0.01 of all image pixels) are different.

  Snapshot: pattern-filter-panel-mobile.png

Call log:
  - Expect "toHaveScreenshot(pattern-filter-panel-mobile.png)" with timeout 5000ms
    - verifying given screenshot expectation
  - taking page screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - 132 pixels (ratio 0.01 of all image pixels) are different.
  - waiting 100ms before taking screenshot
  - taking page screenshot
    - disabled all CSS animations
  - waiting for fonts to load...
  - fonts loaded
  - captured a stable screenshot
  - 132 pixels (ratio 0.01 of all image pixels) are different.

```

# Test source

```ts
  179 | const WIDTHS = [
  180 |     { label: 'desktop', width: 1440, height: 900 },
  181 |     { label: 'mobile', width: 412, height: 915 },
  182 | ];
  183 | 
  184 | test.describe('@visual design-system catalog', () => {
  185 |     /*
  186 |      * NOT `mode: 'serial'`, and that is the point.
  187 |      *
  188 |      * It was serial until 2026-08-25, and serial mode has one consequence that
  189 |      * matters more than anything it was buying: **when a test in a serial group
  190 |      * fails, Playwright skips every remaining test in the group.** With 142 of
  191 |      * this lane's 174 tests in this one group, a change touching several
  192 |      * components reported exactly one failure and silently skipped the rest — so
  193 |      * a re-record looked like "one baseline moved", and a genuinely broken
  194 |      * catalog produced a diff artifact holding a single image. Measured: a
  195 |      * one-line CSS change moved several subjects, and the run reported
  196 |      * `1 failed / 81 did not run` at every worker count, including `--workers=1`
  197 |      * and `--max-failures=0`.
  198 |      *
  199 |      * That is also why the twenty `app.spec.cjs` font failures were all visible
  200 |      * in CI while this file's were not: that describe was never serial.
  201 |      *
  202 |      * Nothing here needed serial. `beforeAll` runs once per worker, so each
  203 |      * worker gets its own catalog server on its own random port (`listen(0)`),
  204 |      * and the subjects are independent screenshots with no shared state and no
  205 |      * ordering between them.
  206 |      */
  207 |     test.describe.configure({ timeout: 120_000 });
  208 | 
  209 |     let catalog;
  210 |     let available;
  211 | 
  212 |     test.beforeAll(async () => {
  213 |         catalog = await startCatalogServer();
  214 |         const index = await (await fetch(`${catalog.base}/index.json`)).json();
  215 |         available = new Set(
  216 |             Object.values(index.entries || {})
  217 |                 .filter((entry) => entry.type !== 'docs')
  218 |                 .map((entry) => entry.id),
  219 |         );
  220 |     });
  221 | 
  222 |     test.afterAll(async () => {
  223 |         catalog?.server?.close();
  224 |     });
  225 | 
  226 |     /**
  227 |      * The tripwire, and the first test in the file on purpose.
  228 |      *
  229 |      * If the runner rasterises with different glyphs, every baseline below
  230 |      * differs for a reason that is not a design-system change. This fails first
  231 |      * and says so, instead of leaving 65 mystery diffs for someone to triage.
  232 |      *
  233 |      * Two assertions, because they fail differently. `interLoaded` is
  234 |      * `document.fonts.check()` — the direct question, which names the cause in
  235 |      * one sentence when the vendored font does not reach the page. The metrics
  236 |      * reading catches what `check()` cannot: a *different build* of Inter, whose
  237 |      * glyphs differ while the family name matches. Neither is
  238 |      * `getComputedStyle().fontFamily`, which names Inter whether or not Inter
  239 |      * loaded and is exactly how a substitution hid for a whole campaign.
  240 |      */
  241 |     const BASELINE_PANGRAM_WIDTH = 426;
  242 | 
  243 |     test('rasterises with the font the baselines were captured with', async ({ page }) => {
  244 |         await page.goto(`${catalog.base}/iframe.html?id=${SUBJECTS[0][0]}&viewMode=story`, { waitUntil: 'networkidle' });
  245 |         await settle(page);
  246 |         const { family, width, interLoaded } = await fontFingerprint(page);
  247 |         expect(
  248 |             interLoaded,
  249 |             `Inter did not load (stack "${family}"). It is served from `
  250 |             + '`src/design-system/fonts/` through `design-system/index.css`, so this is a '
  251 |             + 'build or asset-pipeline failure, not a network one. Every pixel difference in '
  252 |             + 'this run is noise until it is fixed.',
  253 |         ).toBe(true);
  254 |         expect(
  255 |             Math.abs(width - BASELINE_PANGRAM_WIDTH),
  256 |             `text metrics moved (${width}px vs ${BASELINE_PANGRAM_WIDTH}px, stack "${family}"). `
  257 |             + 'Inter loaded, but not the build the baselines were captured with. Check '
  258 |             + '`src/design-system/fonts/` against the diff before re-recording.',
  259 |         ).toBeLessThan(2);
  260 |     });
  261 | 
  262 |     /**
  263 |      * Guards against the subject list silently resolving to nothing — a renamed
  264 |      * story would otherwise just stop being covered.
  265 |      */
  266 |     test('every named subject exists in the built catalog', () => {
  267 |         const missing = SUBJECTS.map(([id]) => id).filter((id) => !available.has(id));
  268 |         expect(missing, 'a renamed story stops being covered without failing anything').toEqual([]);
  269 |     });
  270 | 
  271 |     for (const { label, width, height } of WIDTHS) {
  272 |         for (const [id, name] of SUBJECTS) {
  273 |             test(`${name} @ ${label}`, async ({ page }) => {
  274 |                 test.skip(!available.has(id), `story ${id} is not in the catalog`);
  275 |                 await page.setViewportSize({ width, height });
  276 |                 await freezeClock(page);
  277 |                 await page.goto(`${catalog.base}/iframe.html?id=${id}&viewMode=story`, { waitUntil: 'networkidle' });
  278 |                 await settle(page);
> 279 |                 await expect(page).toHaveScreenshot(`${name}-${label}.png`, { ...SHOT, fullPage: true });
      |                                    ^ Error: expect(page).toHaveScreenshot(expected) failed
  280 |             });
  281 |         }
  282 |     }
  283 | });
  284 | 
```